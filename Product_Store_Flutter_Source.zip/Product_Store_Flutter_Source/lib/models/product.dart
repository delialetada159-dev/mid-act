class Product {
  final int id;
  final String name;
  final double price;
  final String category;
  final String image;

  const Product({
    required this.id,
    required this.name,
    required this.price,
    required this.category,
    required this.image,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'] as int? ?? 0,
      name: json['title'] as String? ?? 'Unknown product',
      price: (json['price'] as num? ?? 0).toDouble(),
      category: json['category'] as String? ?? 'General',
      image: json['thumbnail'] as String? ?? '',
    );
  }
}

class ProductUpdate {
  final Product? product;
  final String? error;

  const ProductUpdate.success(Product value)
      : product = value,
        error = null;

  const ProductUpdate.failure(String message)
      : product = null,
        error = message;
}
