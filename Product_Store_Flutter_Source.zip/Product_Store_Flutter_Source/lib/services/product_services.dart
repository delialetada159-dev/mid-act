import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/product.dart';

class ProductServices {
  static const String apiUrl = 'https://dummyjson.com/products';
  static const Duration requestTimeout = Duration(seconds: 10);

  // Fetch a list once for the FutureBuilder screen.
  static Future<List<Product>> getProducts() async {
    final response = await http
        .get(Uri.parse('$apiUrl?limit=10'))
        .timeout(requestTimeout);

    if (response.statusCode != 200) {
      throw Exception('Unable to load products (${response.statusCode}).');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final items = data['products'] as List<dynamic>? ?? [];

    return items
        .map((item) => Product.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  // Fetch one product by ID for the StreamBuilder screen.
  static Future<Product> getProduct(int id) async {
    final response = await http
        .get(Uri.parse('$apiUrl/$id'))
        .timeout(requestTimeout);

    if (response.statusCode != 200) {
      throw Exception('Unable to load product (${response.statusCode}).');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return Product.fromJson(data);
  }

  // Try a new product every five seconds. A failed request does not end the stream.
  static Stream<ProductUpdate> productStream() async* {
    var productId = 1;

    while (true) {
      try {
        final product = await getProduct(productId);
        yield ProductUpdate.success(product);
      } catch (_) {
        yield const ProductUpdate.failure(
          'Could not load a product. Check your internet connection.',
        );
      }

      productId = productId >= 194 ? 1 : productId + 1;
      await Future.delayed(const Duration(seconds: 5));
    }
  }
}
