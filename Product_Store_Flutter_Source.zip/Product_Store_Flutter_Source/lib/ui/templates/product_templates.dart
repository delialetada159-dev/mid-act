import 'package:flutter/material.dart';

import '../../models/product.dart';
import '../atoms/app_text.dart';
import '../organism/product_card.dart';

class ProductTemplates extends StatelessWidget {
  final List<Product> productList;

  const ProductTemplates({
    super.key,
    required this.productList,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(top: 12, bottom: 12),
      children: [
        const Padding(
          padding: EdgeInsets.all(12),
          child: Center(
            child: AppText(
              text: 'PRODUCT STORE',
              definedStyle: DefinedStyle.pageTitle,
            ),
          ),
        ),
        ...productList.map((product) => ProductCard(product: product)),
      ],
    );
  }
}
