import 'package:flutter/material.dart';
import '../../models/product.dart';
import '../atoms/app_text.dart';

class ProductCard extends StatelessWidget {
  final Product product;

  const ProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
      child: ListTile(
        contentPadding: const EdgeInsets.all(10),
        leading: SizedBox(
          width: 60,
          height: 60,
          child: product.image.isEmpty
              ? const Icon(Icons.shopping_bag_outlined)
              : Image.network(
                  product.image,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) =>
                      const Icon(Icons.shopping_bag_outlined),
                ),
        ),
        title: AppText(
          text: product.name,
          definedStyle: DefinedStyle.productName,
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(
            '${product.category}\n\$${product.price.toStringAsFixed(2)}',
          ),
        ),
        isThreeLine: true,
      ),
    );
  }
}
