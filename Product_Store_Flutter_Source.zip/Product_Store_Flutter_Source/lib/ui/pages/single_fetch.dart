import 'package:flutter/material.dart';

import '../../models/product.dart';
import '../../services/product_services.dart';
import '../templates/product_templates.dart';

class SingleFetch extends StatefulWidget {
  const SingleFetch({super.key});

  @override
  State<SingleFetch> createState() => _SingleFetchState();
}

class _SingleFetchState extends State<SingleFetch> {
  late Future<List<Product>> productsFuture;

  @override
  void initState() {
    super.initState();
    productsFuture = ProductServices.getProducts();
  }

  void retry() {
    setState(() {
      productsFuture = ProductServices.getProducts();
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Product>>(
      future: productsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Could not load products.'),
                const SizedBox(height: 10),
                ElevatedButton(onPressed: retry, child: const Text('Retry')),
              ],
            ),
          );
        }

        final products = snapshot.data ?? [];

        if (products.isEmpty) {
          return const Center(child: Text('There are no products right now.'));
        }

        return ProductTemplates(productList: products);
      },
    );
  }
}
