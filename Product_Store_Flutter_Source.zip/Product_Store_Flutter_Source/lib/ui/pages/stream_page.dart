import 'package:flutter/material.dart';

import '../../models/product.dart';
import '../../services/product_services.dart';
import '../organism/product_card.dart';
import '../atoms/app_text.dart';

class StreamPage extends StatefulWidget {
  const StreamPage({super.key});

  @override
  State<StreamPage> createState() => _StreamPageState();
}

class _StreamPageState extends State<StreamPage> {
  late Stream<ProductUpdate> productUpdates;

  @override
  void initState() {
    super.initState();
    productUpdates = ProductServices.productStream();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<ProductUpdate>(
      stream: productUpdates,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final update = snapshot.data!;

        if (update.error != null) {
          return Center(
            child: Text(
              '${update.error}\nTrying again automatically...',
              textAlign: TextAlign.center,
            ),
          );
        }

        final product = update.product;
        if (product == null) {
          return const Center(child: Text('No product available.'));
        }

        return ListView(
          padding: const EdgeInsets.all(12),
          children: [
            const Padding(
              padding: EdgeInsets.all(12),
              child: Center(
                child: AppText(
                  text: 'LIVE PRODUCT',
                  definedStyle: DefinedStyle.pageTitle,
                ),
              ),
            ),
            ProductCard(product: product),
            const Padding(
              padding: EdgeInsets.all(12),
              child: Center(
                child: Text('Updates automatically every 5 seconds.'),
              ),
            ),
          ],
        );
      },
    );
  }
}
