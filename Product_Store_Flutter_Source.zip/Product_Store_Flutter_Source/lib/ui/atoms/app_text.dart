import 'package:flutter/material.dart';

enum DefinedStyle { pageTitle, productName, normal }

class AppText extends StatelessWidget {
  final String text;
  final DefinedStyle definedStyle;

  const AppText({
    super.key,
    required this.text,
    this.definedStyle = DefinedStyle.normal,
  });

  @override
  Widget build(BuildContext context) {
    final style = switch (definedStyle) {
      DefinedStyle.pageTitle =>
        const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      DefinedStyle.productName =>
        const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      DefinedStyle.normal => const TextStyle(fontSize: 14),
    };

    return Text(text, style: style);
  }
}
