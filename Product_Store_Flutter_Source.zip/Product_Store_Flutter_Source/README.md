# Product Store Flutter API Activity

This is a non-Pokemon adaptation of a Flutter Future/Stream REST API activity. It uses a simple Atomic Design-style folder structure.

## APIs
- Products list: https://dummyjson.com/products?limit=10
- Single product: https://dummyjson.com/products/1 (the ID changes every five seconds in the stream screen)

No API key is required. Internet access is required.

## Install
From the root of your Flutter project, run:

```bash
flutter pub add http
```

Copy this package's `lib` folder into your Flutter project, replacing files with the same names as needed. Then run:

```bash
flutter pub get
flutter analyze
flutter run
```

## Screens
- Products: `FutureBuilder` loads a list once and has loading, error, retry, and empty states.
- Live Product: `StreamBuilder` fetches a different product every five seconds. Errors are emitted as data so one failed request does not stop the stream.
